<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddContentToAnnotationsTable extends Migration
{
    public function up()
    {
        Schema::table('annotations', function (Blueprint $table) {
            $table->text('content')->after('id'); // Adiciona a coluna content
        });
    }

    public function down()
    {
        Schema::table('annotations', function (Blueprint $table) {
            $table->dropColumn('content');
        });
    }
}

