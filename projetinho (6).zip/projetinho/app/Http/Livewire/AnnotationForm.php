<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Annotation;

class AnnotationForm extends Component
{
    public $note = '';
    public $notes = [];

    public function mount()
    {
        $this->notes = Annotation::all()->pluck('content');
    }

    public function saveNote()
    {
        $this->validate([
            'note' => 'required|string|max:255',
        ]);

        Annotation::create(['content' => $this->note]);
        $this->notes->prepend($this->note);
        $this->note = '';
    }

    public function clearNote()
    {
        $this->note = '';
    }

    public function render()
    {
        return view('livewire.annotation-form');
    }
}


