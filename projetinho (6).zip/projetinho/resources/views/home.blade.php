<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Correio Elegante</title>
    <link rel="stylesheet" href="{{ asset('admin-lte/css/adminlte.min.css') }}">
    <link rel="stylesheet" href="{{ asset('admin-lte/plugins/fontawesome-free/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset('admin-lte/plugins/icheck-bootstrap/icheck-bootstrap.min.css') }}">
    <style>
        body {
            background-color: #f8d7da; /* Vermelho claro */
            font-family: Arial, sans-serif;
        }
        .main-header {
            background-color: #dc3545; /* Vermelho */
        }
        .btn-primary {
            background-color: #dc3545; /* Vermelho */
            border-color: #dc3545;
        }
        .btn-primary:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }
        .text-primary {
            color: #dc3545 !important;
        }
        .hero-section {
            text-align: center;
            padding: 50px 20px;
            color: #dc3545;
        }
        .hero-section img {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
        }
        .hero-section h1 {
            font-size: 3em;
            margin-bottom: 20px;
        }
        .hero-section p {
            font-size: 1.5em;
            margin-bottom: 30px;
        }
        .main-header {
            background-color: #dc3545; /* Vermelho */
        }
        .main-sidebar {
            background-color: #e03a3e; /* Vermelho mais escuro */
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="{{ url('/') }}" class="nav-link">Home</a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="{{ route('annotations') }}" class="nav-link">Anotações</a>
                </li>
            </ul>
        </nav>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <a href="{{ url('/') }}" class="brand-link">
                <span class="brand-text font-weight-light">Correio Elegante</span>
            </a>
            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <li class="nav-item">
                            <a href="{{ url('/') }}" class="nav-link">
                                <i class="nav-icon fas fa-home"></i>
                                <p>Home</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('annotations') }}" class="nav-link">
                                <i class="nav-icon fas fa-pencil-alt"></i>
                                <p>Anotações</p>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Hero Section -->
            <section class="hero-section">
                <img src="{{ asset('images/love-image.png') }}" alt="Imagem Romântica"> <!-- Substitua 'amor.jpg' pela sua imagem -->
                <h1>Bem-vindo ao Correio Elegante!</h1>
                <p>Encontre aqui a mensagem perfeita para mandar para o seu xuxu. Deixe seu recado de amor e espalhe carinho.</p>
                <!-- Utiliza o componente Blade -->
                <x-componentinho />
            </section>
        </div>
        <!-- /.content-wrapper -->

        <!-- Main Footer -->
        <footer class="main-footer">
            <div class="float-right d-none d-sm-inline">
                Correio Elegante
            </div>
            <strong>&copy; {{ date('Y') }} <a href="#">Ajudando aos solteirões do Brasil!</a>.</strong> 
        </footer>
    </div>
    <!-- ./wrapper -->

    <!-- Scripts -->
    <script src="{{ asset('admin-lte/plugins/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('admin-lte/plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('admin-lte/js/adminlte.min.js') }}"></script>
</body>
</html>
