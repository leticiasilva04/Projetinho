<div class="card">
    <div class="card-header">
        <h3 class="card-title">Correio Elegante</h3>
    </div>
    <div class="card-body">
        <form wire:submit.prevent="saveNote">
            <div class="form-group">
                <label for="note">Abra seu coração e deixe as palavras escorrerem por seus dedos:</label>
                <input type="text" id="note" wire:model="note" class="form-control" placeholder="Deposite seu amor aqui">
            </div>
            <button type="submit" class="btn btn-primary">Salvar</button>
            <button type="button" wire:click="clearNote" class="btn btn-secondary">Limpar</button>
        </form>
    </div>
    <div class="card-footer">
        <h4>Cartinhas:</h4>
        <ul class="list-group">
            @foreach ($notes as $n)
                <li class="list-group-item">{{ $n }}</li>
            @endforeach
        </ul>
    </div>
</div>

