<div class="text-center mt-4">
    <a href="{{ route('annotations') }}" class="btn btn-primary">Deixe seu recado!</a>
</div>
