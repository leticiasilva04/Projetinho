<div class="text-center mt-4">
    <a href="<?php echo e(route('annotations')); ?>" class="btn btn-primary">Deixe seu recado!</a>
</div>
<?php /**PATH C:\Users\Aluno\projetinho\resources\views/components/componentinho.blade.php ENDPATH**/ ?>