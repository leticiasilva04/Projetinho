

<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">Envie Seu Recado de Amor</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Anotações</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content">
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('annotation-form')->html();
} elseif ($_instance->childHasBeenRendered('ys4tNs5')) {
    $componentId = $_instance->getRenderedChildComponentId('ys4tNs5');
    $componentTag = $_instance->getRenderedChildComponentTagName('ys4tNs5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ys4tNs5');
} else {
    $response = \Livewire\Livewire::mount('annotation-form');
    $html = $response->html();
    $_instance->logRenderedChild('ys4tNs5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aluno\projetinho\resources\views/annotations.blade.php ENDPATH**/ ?>