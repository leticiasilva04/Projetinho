<div class="card">
    <div class="card-header">
        <h3 class="card-title">Correio Elegante</h3>
    </div>
    <div class="card-body">
        <form wire:submit.prevent="saveNote">
            <div class="form-group">
                <label for="note">Abra seu coração e deixe as palavras escorrerem por seus dedos:</label>
                <input type="text" id="note" wire:model="note" class="form-control" placeholder="Deposite seu amor aqui">
            </div>
            <button type="submit" class="btn btn-primary">Salvar</button>
            <button type="button" wire:click="clearNote" class="btn btn-secondary">Limpar</button>
        </form>
    </div>
    <div class="card-footer">
        <h4>Cartinhas:</h4>
        <ul class="list-group">
            <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item"><?php echo e($n); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>

<?php /**PATH C:\Users\Aluno\projetinho\resources\views/livewire/annotation-form.blade.php ENDPATH**/ ?>