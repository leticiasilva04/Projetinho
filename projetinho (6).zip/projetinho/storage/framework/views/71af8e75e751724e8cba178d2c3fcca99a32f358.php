<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Correio Elegante</title>
    <link rel="stylesheet" href="<?php echo e(asset('admin-lte/css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin-lte/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin-lte/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <style>
        body {
            background-color: #f8d7da; /* Vermelho claro */
            font-family: Arial, sans-serif;
        }
        .main-header {
            background-color: #dc3545; /* Vermelho */
        }
        .btn-primary {
            background-color: #dc3545; /* Vermelho */
            border-color: #dc3545;
        }
        .btn-primary:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }
        .text-primary {
            color: #dc3545 !important;
        }
        .hero-section {
            text-align: center;
            padding: 50px 20px;
            color: #dc3545;
        }
        .hero-section img {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
        }
        .hero-section h1 {
            font-size: 3em;
            margin-bottom: 20px;
        }
        .hero-section p {
            font-size: 1.5em;
            margin-bottom: 30px;
        }
        .main-header {
            background-color: #dc3545; /* Vermelho */
        }
        .main-sidebar {
            background-color: #e03a3e; /* Vermelho mais escuro */
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="<?php echo e(url('/')); ?>" class="nav-link">Home</a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="<?php echo e(route('annotations')); ?>" class="nav-link">Anotações</a>
                </li>
            </ul>
        </nav>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <a href="<?php echo e(url('/')); ?>" class="brand-link">
                <span class="brand-text font-weight-light">Correio Elegante</span>
            </a>
            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <li class="nav-item">
                            <a href="<?php echo e(url('/')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-home"></i>
                                <p>Home</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('annotations')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-pencil-alt"></i>
                                <p>Anotações</p>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Hero Section -->
            <section class="hero-section">
                <img src="<?php echo e(asset('images/love-image.png')); ?>" alt="Imagem Romântica"> <!-- Substitua 'amor.jpg' pela sua imagem -->
                <h1>Bem-vindo ao Correio Elegante!</h1>
                <p>Encontre aqui a mensagem perfeita para mandar para o seu xuxu. Deixe seu recado de amor e espalhe carinho.</p>
                <!-- Utiliza o componente Blade -->
                <?php if (isset($component)) { $__componentOriginal978ba3e2dd3e244a1913ac3ac4adf78235baac9f = $component; } ?>
<?php $component = App\View\Components\Componentinho::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('componentinho'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Componentinho::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal978ba3e2dd3e244a1913ac3ac4adf78235baac9f)): ?>
<?php $component = $__componentOriginal978ba3e2dd3e244a1913ac3ac4adf78235baac9f; ?>
<?php unset($__componentOriginal978ba3e2dd3e244a1913ac3ac4adf78235baac9f); ?>
<?php endif; ?>
            </section>
        </div>
        <!-- /.content-wrapper -->

        <!-- Main Footer -->
        <footer class="main-footer">
            <div class="float-right d-none d-sm-inline">
                Correio Elegante
            </div>
            <strong>&copy; <?php echo e(date('Y')); ?> <a href="#">Ajudando aos solteirões do Brasil!</a>.</strong> 
        </footer>
    </div>
    <!-- ./wrapper -->

    <!-- Scripts -->
    <script src="<?php echo e(asset('admin-lte/plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin-lte/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin-lte/js/adminlte.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\Aluno\projetinho\resources\views/home.blade.php ENDPATH**/ ?>