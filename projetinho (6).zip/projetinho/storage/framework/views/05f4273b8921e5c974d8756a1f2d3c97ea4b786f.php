<div>
<h2>Este é um componente! PERSONALIZAR ISSO DEPOIS</h2>
</div><?php /**PATH C:\Users\Aluno\projetinho\resources\views/components/Componentinho.blade.php ENDPATH**/ ?>