<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Correio Elegante</title>
    <?php echo \Livewire\Livewire::styles(); ?>

    <link rel="stylesheet" href="<?php echo e(asset('admin-lte/css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin-lte/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin-lte/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <style>
        .main-header {
            background-color: #dc3545; /* Vermelho */
        }
        .main-sidebar {
            background-color: #e03a3e; /* Vermelho mais escuro */
        }
        .brand-link {
            background-color: #c82333; /* Vermelho escuro */
        }
        .brand-text {
            color: #fff;
        }
        .content-header, .content {
            background-color: #f8d7da; /* Vermelho claro */
        }
        .btn-primary {
            background-color: #dc3545; /* Vermelho */
            border-color: #dc3545;
        }
        .btn-primary:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }
    </style>
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="<?php echo e(route('home')); ?>" class="nav-link">Home</a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="<?php echo e(route('annotations')); ?>" class="nav-link">Anotações</a>
                </li>
            </ul>
        </nav>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <a href="<?php echo e(route('home')); ?>" class="brand-link">
                <span class="brand-text font-weight-light">Correio Elegante</span>
            </a>
            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <li class="nav-item">
                            <a href="<?php echo e(route('home')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-home"></i>
                                <p>Home</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('annotations')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-pencil-alt"></i>
                                <p>Anotações</p>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- /.content-wrapper -->

        <!-- Main Footer -->
        <footer class="main-footer">
            <div class="float-right d-none d-sm-inline">
                Correio Elegante
            </div>
            <strong>&copy; <?php echo e(date('Y')); ?> <a href="#">Seu Nome ou Empresa</a>.</strong> Todos os direitos reservados.
        </footer>
    </div>
    <!-- ./wrapper -->

    <!-- Scripts -->
    <script src="<?php echo e(asset('admin-lte/plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin-lte/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin-lte/js/adminlte.min.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH C:\Users\Aluno\projetinho\resources\views/welcome.blade.php ENDPATH**/ ?>